import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';
import { Text, View, ActivityIndicator } from 'react-native';

// Import screens
import MarketStatusScreen from './components/screens/MarketStatusScreen';
import HomeScreen from './components/screens/HomeScreen';
import CategoryScreen from './components/screens/CategoryScreen';
import ProductDetailScreen from './components/screens/ProductDetailScreen';
import CartScreen from './components/screens/CartScreen';
import CheckoutScreen from './components/screens/CheckoutScreen';
import OrderConfirmationScreen from './components/screens/OrderConfirmationScreen';
import OrderTrackingScreen from './components/screens/OrderTrackingScreen';
import ProfileScreen from './components/screens/ProfileScreen';

const Stack = createStackNavigator();

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [marketIsOpen, setMarketIsOpen] = useState(false);
  
  // Check if the market is open
  useEffect(() => {
    // This would be an API call in a real app
    setTimeout(() => {
      setMarketIsOpen(true);
      setIsLoading(false);
    }, 2000);
  }, []);

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#5C3BFE" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <StatusBar style="auto" />
      <Stack.Navigator initialRouteName="MarketStatus">
        <Stack.Screen 
          name="MarketStatus" 
          component={MarketStatusScreen} 
          initialParams={{ isOpen: marketIsOpen }}
          options={{ headerShown: false }}
        />
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Our Market' }} />
        <Stack.Screen name="Category" component={CategoryScreen} />
        <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
        <Stack.Screen name="Cart" component={CartScreen} />
        <Stack.Screen name="Checkout" component={CheckoutScreen} />
        <Stack.Screen name="OrderConfirmation" component={OrderConfirmationScreen} options={{ headerShown: false }} />
        <Stack.Screen name="OrderTracking" component={OrderTrackingScreen} />
        <Stack.Screen name="Profile" component={ProfileScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}