import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../shared/Header';
import CategoryCard from '../shared/CategoryCard';

// Mock data for categories
const categories = [
  { id: '1', name: 'Fruits & Vegetables', image: require('../../assets/category-fruits.png'), productCount: 45 },
  { id: '2', name: 'Dairy & Eggs', image: require('../../assets/category-dairy.png'), productCount: 32 },
  { id: '3', name: 'Meat & Seafood', image: require('../../assets/category-meat.png'), productCount: 28 },
  { id: '4', name: 'Bakery', image: require('../../assets/category-bakery.png'), productCount: 20 },
  { id: '5', name: 'Beverages', image: require('../../assets/category-beverages.png'), productCount: 15 },
];

// Mock data for popular products
const popularProducts = [
  { id: '1', name: 'Fresh Apples', price: 2.99, image: require('../../assets/apple.png') },
  { id: '2', name: 'Organic Milk', price: 3.49, image: require('../../assets/milk.png') },
  { id: '3', name: 'Whole Wheat Bread', price: 2.29, image: require('../../assets/bread.png') },
  { id: '4', name: 'Chicken Breast', price: 5.99, image: require('../../assets/chicken.png') },
];

export default function HomeScreen({ navigation }) {
  const scrollY = useRef(new Animated.Value(0)).current;
  const [showHeader, setShowHeader] = useState(true);



  const renderProductItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.productItem}
      onPress={() => navigation.navigate('ProductDetail', { productId: item.id })}
    >
      <Image source={item.image} style={styles.productImage} />
      <Text style={styles.productName}>{item.name}</Text>
      <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
      <TouchableOpacity style={styles.addButton}>
        <Ionicons name="add-circle" size={24} color="#5C3BFE" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  // Handler for scroll events
  const handleScroll = event => {
    const offsetY = event.nativeEvent.contentOffset.y;
    setShowHeader(offsetY <= 20);
  };

  return (
    <View style={styles.mainContainer}>
      {/* Custom Header that disappears on scroll */}
      {showHeader && (
        <Header 
          title="Market" 
          showBack={false} 
          showCart={true}  
          showProfile={true}
        />
      )}
      
      <Animated.ScrollView 
        style={styles.container}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        onMomentumScrollEnd={handleScroll}
        onScrollEndDrag={handleScroll}
      >

        
        <View style={styles.header}>
          <TouchableOpacity style={styles.searchBar}>
            <Ionicons name="search" size={20} color="#666" />
            <Text style={styles.searchText}>Search products...</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Cart')}>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Categories</Text>
          <FlatList
            data={categories}
            horizontal
            renderItem={({ item }) => (
              <CategoryCard 
                id={item.id} 
                name={item.name} 
                image={item.image} 
                itemCount={item.productCount} 
              />
            )}
            keyExtractor={item => item.id}
            showsHorizontalScrollIndicator={false}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Popular Items</Text>
          <FlatList
            data={popularProducts}
            renderItem={renderProductItem}
            keyExtractor={item => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Special Offers</Text>
          <View style={styles.offerCard}>
            <Image source={require('../../assets/special-offer.png')} style={styles.offerImage} />
            <View style={styles.offerContent}>
              <Text style={styles.offerTitle}>Weekend Special</Text>
              <Text style={styles.offerDescription}>Get 20% off on all fruits this weekend!</Text>
              <TouchableOpacity style={styles.offerButton}>
                <Text style={styles.offerButtonText}>Shop Now</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },

  header: {
    flexDirection: 'row',
    padding: 15,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f2f2f2',
    borderRadius: 20,
    padding: 10,
    marginRight: 10,
  },
  searchText: {
    marginLeft: 10,
    color: '#999',
    fontSize: 16,
  },
  section: {
    padding: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  productItem: {
    width: 150,
    marginRight: 15,
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  productImage: {
    width: 130,
    height: 100,
    borderRadius: 10,
    alignSelf: 'center',
  },
  productName: {
    marginTop: 10,
    fontSize: 14,
    fontWeight: '500',
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#5C3BFE',
    marginTop: 5,
  },
  addButton: {
    position: 'absolute',
    bottom: 10,
    right: 10,
  },
  offerCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 10,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  offerImage: {
    width: 100,
    height: 100,
  },
  offerContent: {
    flex: 1,
    padding: 15,
  },
  offerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  offerDescription: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
  },
  offerButton: {
    backgroundColor: '#5C3BFE',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    alignSelf: 'flex-start',
    marginTop: 10,
  },
  offerButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});