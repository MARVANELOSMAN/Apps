import React, { useRef,useMemo ,useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Animated,
  Image
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function OrderConfirmationScreen({ route, navigation }) {
  // Get order details from route params
  const { 
    orderId, 
    total, 
    deliveryAddress, 
    paymentMethod,
    estimatedDelivery 
  } = route.params || {};
  
  // Animation values
const fadeAnim = useRef(new Animated.Value(0)).current;
const scaleAnim = useRef(new Animated.Value(0.9)).current;

  
  // Run animations when component mounts
  useEffect(() => {
    // Prevent going back to checkout
    navigation.setOptions({
      headerLeft: () => null,
      gestureEnabled: false
    }[navigation]);
    
    // Start animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true
      })
    ]).start();
  }, [fadeAnim, scaleAnim, navigation]);

  // Format payment method for display
  const getPaymentMethodText = () => {
    switch(paymentMethod) {
      case 'cash': return 'Cash on Delivery';
      case 'card': return 'Credit/Debit Card';
      case 'online': return 'Online Payment';
      default: return 'Not specified';
    }
  };
  
  return (
    <ScrollView style={styles.container}>
      <Animated.View 
        style={[
          styles.confirmationCard,
          { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }
        ]}
      >
        <View style={styles.successIconContainer}>
          <View style={styles.successIconCircle}>
            <Ionicons name="checkmark" size={50} color="#fff" />
          </View>
        </View>
        
        <Text style={styles.successTitle}>Order Confirmed!</Text>
        <Text style={styles.successMessage}>
          Your order has been placed successfully.
        </Text>
        
        <View style={styles.orderInfoSection}>
          <Text style={styles.sectionTitle}>Order Information</Text>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Order ID:</Text>
            <Text style={styles.infoValue}>{orderId}</Text>
          </View>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Date:</Text>
            <Text style={styles.infoValue}>{new Date().toLocaleDateString()}</Text>
          </View>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Time:</Text>
            <Text style={styles.infoValue}>{new Date().toLocaleTimeString()}</Text>
          </View>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Total Amount:</Text>
            <Text style={styles.infoValue}>${total.toFixed(2)}</Text>
          </View>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Payment Method:</Text>
            <Text style={styles.infoValue}>{getPaymentMethodText()}</Text>
          </View>
        </View>
        
        <View style={styles.orderInfoSection}>
          <Text style={styles.sectionTitle}>Delivery Details</Text>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Name:</Text>
            <Text style={styles.infoValue}>{deliveryAddress?.name}</Text>
          </View>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Phone:</Text>
            <Text style={styles.infoValue}>{deliveryAddress?.phone}</Text>
          </View>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Address:</Text>
            <Text style={styles.infoValue}>
              {deliveryAddress?.address}, {deliveryAddress?.city}
              {deliveryAddress?.additionalInfo ? `, ${deliveryAddress.additionalInfo}` : ''}
            </Text>
          </View>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Estimated Delivery:</Text>
            <Text style={styles.infoValue}>{estimatedDelivery}</Text>
          </View>
        </View>
        
        <View style={styles.deliveryTracking}>
          <View style={styles.trackingIllustration}>
            <View style={styles.trackingBubble}>
              <Ionicons name="cart" size={16} color="#fff" />
            </View>
            <View style={styles.trackingLine} />
            <View style={[styles.trackingBubble, styles.trackingBubbleActive]}>
              <Ionicons name="checkmark" size={16} color="#fff" />
            </View>
            <View style={[styles.trackingLine, styles.trackingLineInactive]} />
            <View style={[styles.trackingBubble, styles.trackingBubbleInactive]}>
              <Ionicons name="bicycle" size={16} color="#A8A8A8" />
            </View>
            <View style={[styles.trackingLine, styles.trackingLineInactive]} />
            <View style={[styles.trackingBubble, styles.trackingBubbleInactive]}>
              <Ionicons name="home" size={16} color="#A8A8A8" />
            </View>
          </View>
          
          <View style={styles.trackingLabels}>
            <Text style={styles.trackingLabelActive}>Order Placed</Text>
            <Text style={styles.trackingLabelActive}>Confirmed</Text>
            <Text style={styles.trackingLabel}>On the Way</Text>
            <Text style={styles.trackingLabel}>Delivered</Text>
          </View>
        </View>
        
        <View style={styles.receiptContainer}>
          <Ionicons name="receipt-outline" size={20} color="#5C3BFE" style={styles.receiptIcon} />
          <Text style={styles.receiptText}>
            A receipt has been sent to your phone.
          </Text>
        </View>
      </Animated.View>
      
      <View style={styles.buttonContainer}>
        <TouchableOpacity 
          style={styles.trackOrderButton}
          onPress={() => navigation.navigate('OrderTracking', { orderId })}
        >
          <Text style={styles.trackOrderButtonText}>Track My Order</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.continueButton}
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.continueButtonText}>Continue Shopping</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  confirmationCard: {
    backgroundColor: '#fff',
    borderRadius: 15,
    margin: 15,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  successIconContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  successIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#5C3BFE',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#5C3BFE',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  successTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 10,
  },
  successMessage: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 25,
    paddingHorizontal: 20,
  },
  orderInfoSection: {
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 20,
    paddingBottom: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  infoRow: {
    flexDirection: 'row',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  infoLabel: {
    flex: 0.4,
    fontSize: 15,
    color: '#666',
  },
  infoValue: {
    flex: 0.6,
    fontSize: 15,
    fontWeight: '500',
    color: '#333',
  },
  deliveryTracking: {
    marginTop: 20,
    marginBottom: 10,
  },
  trackingIllustration: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
    marginBottom: 5,
  },
  trackingBubble: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#5C3BFE',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2,
  },
  trackingBubbleActive: {
    backgroundColor: '#5C3BFE',
  },
  trackingBubbleInactive: {
    backgroundColor: '#D8D8D8',
  },
  trackingLine: {
    height: 3,
    flex: 1,
    backgroundColor: '#5C3BFE',
    zIndex: 1,
  },
  trackingLineInactive: {
    backgroundColor: '#E0E0E0',
  },
  trackingLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 0,
  },
  trackingLabel: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    width: '25%',
  },
  trackingLabelActive: {
    fontSize: 12,
    color: '#5C3BFE',
    fontWeight: '500',
    textAlign: 'center',
    width: '25%',
  },
  receiptContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0EEFF',
    padding: 15,
    borderRadius: 10,
    marginVertical: 20,
  },
  receiptIcon: {
    marginRight: 10,
  },
  receiptText: {
    fontSize: 14,
    color: '#5C3BFE',
  },
  buttonContainer: {
    padding: 15,
    marginBottom: 30,
  },
  trackOrderButton: {
    backgroundColor: '#5C3BFE',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    marginBottom: 10,
  },
  trackOrderButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  continueButton: {
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#5C3BFE',
  },
  continueButtonText: {
    color: '#5C3BFE',
    fontSize: 16,
    fontWeight: 'bold',
  },
});