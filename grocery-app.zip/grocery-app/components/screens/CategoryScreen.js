import React from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Mock data for products in a category
const products = [
  { id: '1', name: 'Red Apples', price: 2.99, image: require('../../assets/apple.png') },
  { id: '2', name: 'Bananas', price: 1.49, image: require('../../assets/banana.png') },
  { id: '3', name: 'Oranges', price: 3.29, image: require('../../assets/orange.png') },
  { id: '4', name: 'Strawberries', price: 4.99, image: require('../../assets/strawberry.png') },
  { id: '5', name: 'Grapes', price: 3.99, image: require('../../assets/grapes.png') },
  { id: '6', name: 'Watermelon', price: 5.49, image: require('../../assets/watermelon.png') },
];

export default function CategoryScreen({ route, navigation }) {
  const { categoryName } = route.params;
  
  // Update the navigation title with the category name
  React.useEffect(() => {
    navigation.setOptions({ title: categoryName });
  }, [navigation, categoryName]);

  const renderProductItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.productItem}
      onPress={() => navigation.navigate('ProductDetail', { productId: item.id })}
    >
      <Image source={item.image} style={styles.productImage} />
      <View style={styles.productInfo}>
        <Text style={styles.productName}>{item.name}</Text>
        <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
      </View>
      <TouchableOpacity style={styles.addButton}>
        <Ionicons name="add-circle" size={28} color="#5C3BFE" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={products}
        renderItem={renderProductItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.productList}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  productList: {
    padding: 15,
  },
  productItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 15,
    padding: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  productImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
  },
  productInfo: {
    flex: 1,
    marginLeft: 15,
  },
  productName: {
    fontSize: 16,
    fontWeight: '500',
  },
  productPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#5C3BFE',
    marginTop: 5,
  },
  addButton: {
    padding: 5,
  },
});