import React, { useMemo, useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Animated
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import StatusIndicator from '../shared/StatusIndicator';

export default function OrderTrackingScreen({ route, navigation }) {
  const { orderId } = route.params || { orderId: 'Unknown' };
  
  // Mock data for delivery status - in a real app, this would come from your API
  const [orderStatus, setOrderStatus] = useState({
    status: 'preparing', // 'preparing', 'on_the_way', 'delivered'
    estimatedDelivery: '30-45 minutes',
    courier: {
      name: 'Michael Johnson',
      phone: '+1 987-654-3210'
    },
    orderTime: new Date().toLocaleTimeString(),
    progress: 0.3, // Progress from 0 to 1
  });

  // Animation value for progress bar
const progressAnim = useMemo(() => new Animated.Value(0), []);
  
  // Simulate order status updates
useEffect(() => {
  const progress = orderStatus.progress;
  const status = orderStatus.status;

  // Animate progress bar to current value
  Animated.timing(progressAnim, {
    toValue: progress,
    duration: 1000,
    useNativeDriver: false,
  }).start();

  const timer = setTimeout(() => {
    setOrderStatus(prevState => {
      if (prevState.status === 'preparing') {
        return { ...prevState, status: 'on_the_way', progress: 0.6 };
      } else if (prevState.status === 'on_the_way') {
        return { ...prevState, status: 'delivered', progress: 1 };
      }
      return prevState;
    });
  }, 10000);

  return () => clearTimeout(timer);
}, [orderStatus.status, orderStatus.progress, progressAnim]); 

  // Get status step index
  const getStatusStep = () => {
    switch(orderStatus.status) {
      case 'preparing': return 1;
      case 'on_the_way': return 2;
      case 'delivered': return 3;
      default: return 0;
    }
  };

  // Status step labels
  const statusSteps = [
    'Order Placed',
    'Preparing',
    'On the Way',
    'Delivered'
  ];

  // Get estimated arrival text
  const getEstimatedArrival = () => {
    if (orderStatus.status === 'delivered') {
      return 'Order delivered!';
    } else if (orderStatus.status === 'on_the_way') {
      return `Arriving in approximately ${orderStatus.estimatedDelivery}`;
    } else {
      return `Estimated delivery time: ${orderStatus.estimatedDelivery}`;
    }
  };

  // Contact courier
  const contactCourier = () => {
    // In a real app, this would initiate a phone call
    alert(`Calling ${orderStatus.courier.name} at ${orderStatus.courier.phone}`);
  };

  return (
    <View style={styles.container}>
      <StatusIndicator status="processing" text="Your order is being prepared" />
      <ScrollView>
        <View style={styles.headerSection}>
          <Text style={styles.orderId}>Order #{orderId}</Text>
          <Text style={styles.orderTime}>Placed at {orderStatus.orderTime}</Text>
          
          <View style={styles.estimatedArrivalContainer}>
            <Text style={styles.estimatedArrivalTitle}>
              {getEstimatedArrival()}
            </Text>
            
            <View style={styles.progressBarContainer}>
              <Animated.View 
                style={[
                  styles.progressBar,
                  { width: progressAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0%', '100%']
                  })}
                ]}
              />
            </View>
          </View>
        </View>
        
        <View style={styles.trackingSection}>
          <Text style={styles.sectionTitle}>Delivery Status</Text>
          
          <View style={styles.stepsContainer}>
            {statusSteps.map((step, index) => (
              <View key={index} style={styles.stepItem}>
                <View 
                  style={[
                    styles.stepCircle,
                    index <= getStatusStep() ? styles.activeStep : styles.inactiveStep
                  ]}
                >
                  {index < getStatusStep() ? (
                    <Ionicons name="checkmark" size={16} color="#fff" />
                  ) : (
                    <Text style={index === getStatusStep() ? styles.activeStepText : styles.inactiveStepText}>
                      {index + 1}
                    </Text>
                  )}
                </View>
                
                {index < statusSteps.length - 1 && (
                  <View 
                    style={[
                      styles.stepLine,
                      index < getStatusStep() ? styles.activeStepLine : styles.inactiveStepLine
                    ]}
                  />
                )}
                
                <Text style={[
                  styles.stepLabel,
                  index <= getStatusStep() ? styles.activeStepLabel : styles.inactiveStepLabel
                ]}>
                  {step}
                </Text>
                
                {index === 1 && orderStatus.status === 'preparing' && (
                  <Text style={styles.currentStatusText}>Current Status</Text>
                )}
                
                {index === 2 && orderStatus.status === 'on_the_way' && (
                  <Text style={styles.currentStatusText}>Current Status</Text>
                )}
                
                {index === 3 && orderStatus.status === 'delivered' && (
                  <Text style={styles.currentStatusText}>Current Status</Text>
                )}
              </View>
            ))}
          </View>
        </View>
        
        {orderStatus.status === 'on_the_way' && (
          <View style={styles.courierSection}>
            <Text style={styles.sectionTitle}>Delivery Information</Text>
            
            <View style={styles.courierInfo}>
              <View style={styles.courierImageContainer}>
                <Ionicons name="person-circle" size={60} color="#5C3BFE" />
              </View>
              
              <View style={styles.courierDetails}>
                <Text style={styles.courierName}>{orderStatus.courier.name}</Text>
                <Text style={styles.courierPhone}>{orderStatus.courier.phone}</Text>
              </View>
              
              <TouchableOpacity 
                style={styles.contactButton}
                onPress={contactCourier}
              >
                <Ionicons name="call" size={20} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        )}
        
        <View style={styles.orderDetailsSection}>
          <Text style={styles.sectionTitle}>Order Details</Text>
          
          <TouchableOpacity 
            style={styles.orderDetailsButton}
            onPress={() => navigation.navigate('OrderConfirmation', { orderId })}
          >
            <Text style={styles.orderDetailsButtonText}>View Order Details</Text>
            <Ionicons name="chevron-forward" size={20} color="#5C3BFE" />
          </TouchableOpacity>
        </View>
        
        <View style={styles.helpSection}>
          <Text style={styles.sectionTitle}>Need Help?</Text>
          
          <TouchableOpacity style={styles.helpButton}>
            <Ionicons name="help-circle-outline" size={24} color="#5C3BFE" />
            <Text style={styles.helpButtonText}>Get Help with Order</Text>
          </TouchableOpacity>
        </View>
        
        {orderStatus.status !== 'delivered' && (
          <TouchableOpacity 
            style={styles.cancelButton}
            onPress={() => alert('Are you sure you want to cancel this order?')}
          >
            <Text style={styles.cancelButtonText}>Cancel Order</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  headerSection: {
    backgroundColor: '#fff',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  orderId: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  orderTime: {
    color: '#666',
    marginBottom: 15,
  },
  estimatedArrivalContainer: {
    marginTop: 10,
  },
  estimatedArrivalTitle: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 10,
    color: '#5C3BFE',
  },
  progressBarContainer: {
    height: 8,
    backgroundColor: '#eee',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#5C3BFE',
    borderRadius: 4,
  },
  trackingSection: {
    backgroundColor: '#fff',
    padding: 20,
    marginTop: 15,
    borderRadius: 10,
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  stepsContainer: {
    flexDirection: 'column',
    marginTop: 10,
  },
  stepItem: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    marginBottom: 20,
    position: 'relative',
  },
  stepCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    marginBottom: 5,
    zIndex: 2,
  },
  activeStep: {
    backgroundColor: '#5C3BFE',
  },
  inactiveStep: {
    backgroundColor: '#ddd',
  },
  activeStepText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  inactiveStepText: {
    color: '#666',
    fontWeight: 'bold',
  },
  stepLine: {
    position: 'absolute',
    left: 15,
    top: 30,
    width: 2,
    height: 40,
    zIndex: 1,
  },
  activeStepLine: {
    backgroundColor: '#5C3BFE',
  },
  inactiveStepLine: {
    backgroundColor: '#ddd',
  },
  stepLabel: {
    marginLeft: 40,
    marginTop: -25,
    fontSize: 16,
  },
  activeStepLabel: {
    fontWeight: '500',
    color: '#333',
  },
  inactiveStepLabel: {
    color: '#999',
  },
  currentStatusText: {
    position: 'absolute',
    right: 0,
    top: 0,
    backgroundColor: '#F0EEFF',
    color: '#5C3BFE',
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 20,
    fontSize: 12,
    fontWeight: '500',
  },
  courierSection: {
    backgroundColor: '#fff',
    padding: 20,
    marginTop: 15,
    borderRadius: 10,
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  courierInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  courierImageContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#F0EEFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  courierDetails: {
    flex: 1,
  },
  courierName: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 3,
  },
  courierPhone: {
    color: '#666',
    marginBottom: 3,
  },
  contactButton: {
    backgroundColor: '#5C3BFE',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  orderDetailsSection: {
    backgroundColor: '#fff',
    padding: 20,
    marginTop: 15,
    borderRadius: 10,
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  orderDetailsButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#eee',
    borderRadius: 8,
    paddingHorizontal: 15,
  },
  orderDetailsButtonText: {
    fontSize: 16,
    color: '#5C3BFE',
  },
  helpSection: {
    backgroundColor: '#fff',
    padding: 20,
    marginTop: 15,
    borderRadius: 10,
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    marginBottom: 15,
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
  },
  helpButtonText: {
    marginLeft: 10,
    fontSize: 16,
    color: '#5C3BFE',
  },
  cancelButton: {
    margin: 15,
    padding: 15,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#FF6B6B',
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 30,
  },
  cancelButtonText: {
    color: '#FF6B6B',
    fontSize: 16,
    fontWeight: '500',
  },
});