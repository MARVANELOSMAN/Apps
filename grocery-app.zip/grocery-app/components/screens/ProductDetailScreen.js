import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Image, 
  TouchableOpacity, 
  Dimensions 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

export default function ProductDetailScreen({ route, navigation }) {
  const { productId } = route.params || { productId: '1' };
  
  // State for product quantity
  const [quantity, setQuantity] = useState(1);
  
  // Mock product data - in a real app, you would fetch this based on productId
  const [product, setProduct] = useState({
    id: productId,
    name: 'Organic Red Apples',
    price: 2.99,
    image: require('../../assets/apple.png'),
    description: 'Fresh, organic red apples. Sweet and crisp with a juicy flesh. Grown locally without the use of pesticides. Perfect for eating, baking, or making applesauce.',
    weight: '500g (approx. 4-5 apples)',
    nutritionFacts: {
      calories: 95,
      fat: '0.3g',
      carbs: '25g',
      protein: '0.5g',
      fiber: '4.4g',
      sugar: '19g'
    },
    inStock: true,
    discount: 0,
    rating: 4.7,
    reviews: 42
  });
  
  // Update navigation title
  useEffect(() => {
    navigation.setOptions({
      title: product.name
    });
  }, [product,navigation]);
  
  // Increase quantity
  const increaseQuantity = () => {
    setQuantity(quantity + 1);
  };
  
  // Decrease quantity
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  
  // Add to cart
  const addToCart = () => {
    // In a real app, this would update your cart state/context
    alert(`Added ${quantity} ${product.name} to cart!`);
    // Optionally navigate to cart
    // navigation.navigate('Cart');
  };
  
  return (
    <ScrollView style={styles.container}>
      {/* Product Image */}
      <View style={styles.imageContainer}>
        <Image source={product.image} style={styles.productImage} />
        {product.discount > 0 && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>{product.discount}% OFF</Text>
          </View>
        )}
      </View>
      
      {/* Product Info */}
      <View style={styles.productInfoContainer}>
        <View style={styles.nameRow}>
          <Text style={styles.productName}>{product.name}</Text>
          <View style={styles.ratingContainer}>
            <Ionicons name="star" size={16} color="#FFD700" />
            <Text style={styles.ratingText}>{product.rating}</Text>
            <Text style={styles.reviewsText}>({product.reviews})</Text>
          </View>
        </View>
        
        <Text style={styles.productWeight}>{product.weight}</Text>
        
        <View style={styles.priceRow}>
          <Text style={styles.productPrice}>${product.price.toFixed(2)}</Text>
          {product.inStock ? (
            <Text style={styles.inStockText}>In Stock</Text>
          ) : (
            <Text style={styles.outOfStockText}>Out of Stock</Text>
          )}
        </View>
      </View>
      
      {/* Quantity Selector */}
      <View style={styles.quantityContainer}>
        <Text style={styles.quantityTitle}>Quantity</Text>
        <View style={styles.quantitySelector}>
          <TouchableOpacity 
            onPress={decreaseQuantity} 
            style={styles.quantityButton}
            disabled={quantity <= 1}
          >
            <Ionicons 
              name="remove" 
              size={20} 
              color={quantity <= 1 ? '#ccc' : '#5C3BFE'} 
            />
          </TouchableOpacity>
          
          <Text style={styles.quantityText}>{quantity}</Text>
          
          <TouchableOpacity 
            onPress={increaseQuantity}
            style={styles.quantityButton}
          >
            <Ionicons name="add" size={20} color="#5C3BFE" />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Description */}
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Description</Text>
        <Text style={styles.descriptionText}>{product.description}</Text>
      </View>
      
      {/* Nutrition Facts */}
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Nutrition Facts</Text>
        <View style={styles.nutritionContainer}>
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{product.nutritionFacts.calories}</Text>
            <Text style={styles.nutritionLabel}>Calories</Text>
          </View>
          
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{product.nutritionFacts.fat}</Text>
            <Text style={styles.nutritionLabel}>Fat</Text>
          </View>
          
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{product.nutritionFacts.carbs}</Text>
            <Text style={styles.nutritionLabel}>Carbs</Text>
          </View>
          
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{product.nutritionFacts.protein}</Text>
            <Text style={styles.nutritionLabel}>Protein</Text>
          </View>
          
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{product.nutritionFacts.fiber}</Text>
            <Text style={styles.nutritionLabel}>Fiber</Text>
          </View>
          
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{product.nutritionFacts.sugar}</Text>
            <Text style={styles.nutritionLabel}>Sugar</Text>
          </View>
        </View>
      </View>
      
      {/* Add to Cart Button */}
      <View style={styles.addToCartContainer}>
        <Text style={styles.totalText}>
          Total: <Text style={styles.totalPrice}>${(product.price * quantity).toFixed(2)}</Text>
        </Text>
        
        <TouchableOpacity 
          style={[
            styles.addToCartButton,
            !product.inStock && styles.disabledButton
          ]}
          onPress={addToCart}
          disabled={!product.inStock}
        >
          <Ionicons name="cart" size={20} color="#fff" style={styles.cartIcon} />
          <Text style={styles.addToCartText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  imageContainer: {
    width: '100%',
    height: 250,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  productImage: {
    width: '80%',
    height: '80%',
    resizeMode: 'contain',
  },
  discountBadge: {
    position: 'absolute',
    top: 15,
    left: 15,
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
  },
  discountText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
  },
  productInfoContainer: {
    backgroundColor: '#fff',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  nameRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 5,
  },
  productName: {
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
    marginRight: 10,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  reviewsText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 3,
  },
  productWeight: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  productPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#5C3BFE',
  },
  inStockText: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '500',
  },
  outOfStockText: {
    fontSize: 14,
    color: '#FF6B6B',
    fontWeight: '500',
  },
  quantityContainer: {
    backgroundColor: '#fff',
    padding: 15,
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  quantityTitle: {
    fontSize: 16,
    fontWeight: '500',
  },
  quantitySelector: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#eee',
    overflow: 'hidden',
  },
  quantityButton: {
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantityText: {
    fontSize: 16,
    fontWeight: 'bold',
    paddingHorizontal: 15,
  },
  sectionContainer: {
    backgroundColor: '#fff',
    padding: 15,
    marginTop: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  descriptionText: {
    fontSize: 14,
    lineHeight: 20,
    color: '#444',
  },
  nutritionContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginVertical: 5,
  },
  nutritionItem: {
    width: '33.33%',
    padding: 10,
    alignItems: 'center',
  },
  nutritionValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#5C3BFE',
  },
  nutritionLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 3,
  },
  addToCartContainer: {
    backgroundColor: '#fff',
    padding: 15,
    marginTop: 10,
    marginBottom: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalText: {
    fontSize: 16,
  },
  totalPrice: {
    fontWeight: 'bold',
    color: '#5C3BFE',
  },
  addToCartButton: {
    backgroundColor: '#5C3BFE',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  disabledButton: {
    backgroundColor: '#ccc',
  },
  cartIcon: {
    marginRight: 8,
  },
  addToCartText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});