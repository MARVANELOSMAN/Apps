import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Image,
  Switch
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function ProfileScreen({ navigation }) {
  // User data state - in a real app, this would come from your authentication system
  const [userData, setUserData] = useState({
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1 123-456-7890',
    notificationsEnabled: true,
    savedAddresses: [
      { id: '1', name: 'Home', address: '123 Main St, Anytown, USA' },
      { id: '2', name: 'Work', address: '456 Office Blvd, Business District, USA' }
    ],
    paymentMethods: [
      { id: '1', type: 'card', last4: '4242', brand: 'Visa' },
      { id: '2', type: 'card', last4: '1234', brand: 'Mastercard' }
    ]
  });

  // Mock data for recent orders
  const recentOrders = [
    { id: 'ORD-345678', date: '2023-08-10', total: 32.50, items: 5, status: 'Delivered' },
    { id: 'ORD-234567', date: '2023-07-28', total: 45.75, items: 8, status: 'Delivered' },
    { id: 'ORD-123456', date: '2023-07-15', total: 28.25, items: 3, status: 'Delivered' }
  ];
  
  // Toggle notifications
  const toggleNotifications = () => {
    setUserData({
      ...userData,
      notificationsEnabled: !userData.notificationsEnabled
    });
  };
  
  // Logout handler
  const handleLogout = () => {
    // In a real app, this would clear the authentication state
    alert('Logging out...');
    // Navigate to login or home screen
    navigation.navigate('MarketStatus');
  };
  
  return (
    <ScrollView style={styles.container}>
      {/* User Profile Header */}
      <View style={styles.profileHeader}>
        <View style={styles.profileImageContainer}>
          <Text style={styles.profileInitials}>
            {userData.name.split(' ').map(n => n[0]).join('')}
          </Text>
        </View>
        
        <View style={styles.profileInfo}>
          <Text style={styles.profileName}>{userData.name}</Text>
          <Text style={styles.profileEmail}>{userData.email}</Text>
          <Text style={styles.profilePhone}>{userData.phone}</Text>
        </View>
        
        <TouchableOpacity style={styles.editProfileButton}>
          <Ionicons name="pencil" size={16} color="#fff" />
        </TouchableOpacity>
      </View>
      
      {/* Recent Orders */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Orders</Text>
          <TouchableOpacity>
            <Text style={styles.viewAllButton}>View All</Text>
          </TouchableOpacity>
        </View>
        
        {recentOrders.map(order => (
          <TouchableOpacity 
            key={order.id}
            style={styles.orderItem}
            onPress={() => navigation.navigate('OrderConfirmation', { orderId: order.id })}
          >
            <View style={styles.orderMain}>
              <Text style={styles.orderId}>{order.id}</Text>
              <Text style={styles.orderDate}>{new Date(order.date).toLocaleDateString()}</Text>
            </View>
            
            <View style={styles.orderDetails}>
              <Text style={styles.orderAmount}>${order.total.toFixed(2)}</Text>
              <View style={styles.orderStatusContainer}>
                <View style={styles.orderStatusDot} />
                <Text style={styles.orderStatus}>{order.status}</Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </View>
      
      {/* Saved Addresses */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Saved Addresses</Text>
          <TouchableOpacity>
            <Text style={styles.viewAllButton}>Add New</Text>
          </TouchableOpacity>
        </View>
        
        {userData.savedAddresses.map(address => (
          <View key={address.id} style={styles.addressItem}>
            <View style={styles.addressIcon}>
              <Ionicons 
                name={address.name === 'Home' ? 'home' : 'business'} 
                size={20} 
                color="#5C3BFE" 
              />
            </View>
            
            <View style={styles.addressInfo}>
              <Text style={styles.addressName}>{address.name}</Text>
              <Text style={styles.addressText}>{address.address}</Text>
            </View>
            
            <TouchableOpacity style={styles.addressActionButton}>
              <Ionicons name="ellipsis-vertical" size={18} color="#666" />
            </TouchableOpacity>
          </View>
        ))}
      </View>
      
      {/* Payment Methods */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Payment Methods</Text>
          <TouchableOpacity>
            <Text style={styles.viewAllButton}>Add New</Text>
          </TouchableOpacity>
        </View>
        
        {userData.paymentMethods.map(method => (
          <View key={method.id} style={styles.paymentItem}>
            <View style={styles.paymentIcon}>
              <Ionicons 
                name={method.brand === 'Visa' ? 'card' : 'card-outline'} 
                size={20} 
                color="#5C3BFE" 
              />
            </View>
            
            <View style={styles.paymentInfo}>
              <Text style={styles.paymentMethod}>
                {method.brand} •••• {method.last4}
              </Text>
            </View>
            
            <TouchableOpacity style={styles.paymentActionButton}>
              <Ionicons name="ellipsis-vertical" size={18} color="#666" />
            </TouchableOpacity>
          </View>
        ))}
      </View>
      
      {/* Preferences */}
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Settings</Text>
        
        <View style={styles.preferenceItem}>
          <View style={styles.preferenceInfo}>
            <Ionicons name="notifications-outline" size={20} color="#5C3BFE" style={styles.preferenceIcon} />
            <Text style={styles.preferenceText}>Push Notifications</Text>
          </View>
          
          <Switch
            value={userData.notificationsEnabled}
            onValueChange={toggleNotifications}
            trackColor={{ false: '#ccc', true: '#d4c4ff' }}
            thumbColor={userData.notificationsEnabled ? '#5C3BFE' : '#f4f3f4'}
          />
        </View>
        
        <TouchableOpacity style={styles.preferenceItem}>
          <View style={styles.preferenceInfo}>
            <Ionicons name="language-outline" size={20} color="#5C3BFE" style={styles.preferenceIcon} />
            <Text style={styles.preferenceText}>Language</Text>
          </View>
          
          <View style={styles.preferenceAction}>
            <Text style={styles.preferenceValue}>English</Text>
            <Ionicons name="chevron-forward" size={18} color="#666" />
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.preferenceItem}>
          <View style={styles.preferenceInfo}>
            <Ionicons name="help-circle-outline" size={20} color="#5C3BFE" style={styles.preferenceIcon} />
            <Text style={styles.preferenceText}>Help Center</Text>
          </View>
          
          <View style={styles.preferenceAction}>
            <Ionicons name="chevron-forward" size={18} color="#666" />
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.preferenceItem}>
          <View style={styles.preferenceInfo}>
            <Ionicons name="document-text-outline" size={20} color="#5C3BFE" style={styles.preferenceIcon} />
            <Text style={styles.preferenceText}>Terms & Policies</Text>
          </View>
          
          <View style={styles.preferenceAction}>
            <Ionicons name="chevron-forward" size={18} color="#666" />
          </View>
        </TouchableOpacity>
      </View>
      
      {/* Logout Button */}
      <TouchableOpacity 
        style={styles.logoutButton}
        onPress={handleLogout}
      >
        <Ionicons name="log-out-outline" size={20} color="#FF6B6B" style={styles.logoutIcon} />
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
      
      <View style={styles.versionInfo}>
        <Text style={styles.versionText}>Version 1.0.0</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  profileHeader: {
    backgroundColor: '#fff',
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  profileImageContainer: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#5C3BFE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInitials: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  profileInfo: {
    flex: 1,
    marginLeft: 15,
  },
  profileName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 3,
  },
  profileEmail: {
    fontSize: 14,
    color: '#666',
    marginBottom: 2,
  },
  profilePhone: {
    fontSize: 14,
    color: '#666',
  },
  editProfileButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#5C3BFE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionContainer: {
    backgroundColor: '#fff',
    padding: 15,
    marginTop: 15,
    borderRadius: 10,
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  viewAllButton: {
    fontSize: 14,
    color: '#5C3BFE',
  },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    paddingVertical: 12,
  },
  orderMain: {
    flex: 1,
  },
  orderId: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 3,
  },
  orderDate: {
    fontSize: 12,
    color: '#666',
  },
  orderDetails: {
    alignItems: 'flex-end',
  },
  orderAmount: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#5C3BFE',
    marginBottom: 3,
  },
  orderStatusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  orderStatusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4CAF50',
    marginRight: 5,
  },
  orderStatus: {
    fontSize: 12,
    color: '#4CAF50',
  },
  addressItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  addressIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F0EEFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  addressInfo: {
    flex: 1,
  },
  addressName: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 3,
  },
  addressText: {
    fontSize: 13,
    color: '#666',
  },
  addressActionButton: {
    padding: 5,
  },
  paymentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  paymentIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F0EEFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  paymentInfo: {
    flex: 1,
  },
  paymentMethod: {
    fontSize: 14,
    fontWeight: '500',
  },
  paymentActionButton: {
    padding: 5,
  },
  preferenceItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  preferenceInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  preferenceIcon: {
    marginRight: 12,
  },
  preferenceText: {
    fontSize: 15,
  },
  preferenceAction: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  preferenceValue: {
    fontSize: 14,
    color: '#666',
    marginRight: 5,
  },
  logoutButton: {
    margin: 15,
    padding: 12,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#FF6B6B',
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoutIcon: {
    marginRight: 8,
  },
  logoutText: {
    fontSize: 16,
    color: '#FF6B6B',
    fontWeight: '500',
  },
  versionInfo: {
    alignItems: 'center',
    marginBottom: 30,
    marginTop: 10,
  },
  versionText: {
    fontSize: 12,
    color: '#999',
  },
});