import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  TextInput,
  Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Button from '../shared/Button'; // Added import for Button component

export default function CheckoutScreen({ route, navigation }) {
  const { total } = route.params || { total: 0 };
  
  // Added state for tracking submission status
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // State for delivery address
  const [deliveryAddress, setDeliveryAddress] = useState({
    name: 'John Doe',
    phone: '+1 123-456-7890',
    address: '123 Main Street',
    city: 'Anytown',
    additionalInfo: 'Apartment 4B'
  });

  // State for payment method
  const [paymentMethod, setPaymentMethod] = useState('cash');
  
  // State for delivery time
  const [deliveryTime, setDeliveryTime] = useState('asap');
  
  // Function to handle order placement
  const placeOrder = () => {
    // Set submission state to true when starting
    setIsSubmitting(true);
    
    // In a real app, you would:
    // 1. Validate all fields
    // 2. Send order to backend
    // 3. Process payment if not cash
    // 4. Navigate to confirmation screen
    
    // Simulating a successful order
    setTimeout(() => {
      // Navigate to order confirmation with order details
      navigation.navigate('OrderConfirmation', {
        orderId: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
        total: total,
        deliveryAddress: deliveryAddress,
        paymentMethod: paymentMethod,
        estimatedDelivery: deliveryTime === 'asap' ? '30-45 minutes' : 'Scheduled for ' + deliveryTime
      });
      // Reset submission state (though not necessary since we're navigating away)
      setIsSubmitting(false);
    }, 1500);
  };

  // Function to edit delivery address
  const editAddress = (field, value) => {
    setDeliveryAddress({
      ...deliveryAddress,
      [field]: value
    });
  };

  return (
    <ScrollView style={styles.container}>
      {/* Delivery Address Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Delivery Address</Text>
        
        <View style={styles.addressForm}>
          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>Full Name</Text>
            <TextInput
              style={styles.input}
              value={deliveryAddress.name}
              onChangeText={(text) => editAddress('name', text)}
              placeholder="Enter your full name"
            />
          </View>
          
          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>Phone Number</Text>
            <TextInput
              style={styles.input}
              value={deliveryAddress.phone}
              onChangeText={(text) => editAddress('phone', text)}
              placeholder="Enter your phone number"
              keyboardType="phone-pad"
            />
          </View>
          
          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>Address</Text>
            <TextInput
              style={styles.input}
              value={deliveryAddress.address}
              onChangeText={(text) => editAddress('address', text)}
              placeholder="Enter your street address"
            />
          </View>
          
          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>City</Text>
            <TextInput
              style={styles.input}
              value={deliveryAddress.city}
              onChangeText={(text) => editAddress('city', text)}
              placeholder="Enter your city"
            />
          </View>
          
          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>Additional Info</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={deliveryAddress.additionalInfo}
              onChangeText={(text) => editAddress('additionalInfo', text)}
              placeholder="Apartment number, building, landmark, etc."
              multiline={true}
              numberOfLines={3}
            />
          </View>
        </View>
      </View>
      
      {/* Payment Method Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Payment Method</Text>
        
        <TouchableOpacity 
          style={[
            styles.paymentOption, 
            paymentMethod === 'cash' && styles.selectedPayment
          ]}
          onPress={() => setPaymentMethod('cash')}
        >
          <Ionicons 
            name="cash-outline" 
            size={24} 
            color={paymentMethod === 'cash' ? "#5C3BFE" : "#666"} 
          />
          <Text style={[
            styles.paymentOptionText,
            paymentMethod === 'cash' && styles.selectedPaymentText
          ]}>
            Cash on Delivery
          </Text>
          {paymentMethod === 'cash' && (
            <Ionicons name="checkmark-circle" size={24} color="#5C3BFE" />
          )}
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.paymentOption, 
            paymentMethod === 'card' && styles.selectedPayment
          ]}
          onPress={() => setPaymentMethod('card')}
        >
          <Ionicons 
            name="card-outline" 
            size={24} 
            color={paymentMethod === 'card' ? "#5C3BFE" : "#666"} 
          />
          <Text style={[
            styles.paymentOptionText,
            paymentMethod === 'card' && styles.selectedPaymentText
          ]}>
            Credit/Debit Card
          </Text>
          {paymentMethod === 'card' && (
            <Ionicons name="checkmark-circle" size={24} color="#5C3BFE" />
          )}
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.paymentOption, 
            paymentMethod === 'online' && styles.selectedPayment
          ]}
          onPress={() => setPaymentMethod('online')}
        >
          <Ionicons 
            name="globe-outline" 
            size={24} 
            color={paymentMethod === 'online' ? "#5C3BFE" : "#666"} 
          />
          <Text style={[
            styles.paymentOptionText,
            paymentMethod === 'online' && styles.selectedPaymentText
          ]}>
            Online Payment
          </Text>
          {paymentMethod === 'online' && (
            <Ionicons name="checkmark-circle" size={24} color="#5C3BFE" />
          )}
        </TouchableOpacity>
      </View>
      
      {/* Delivery Time Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Delivery Time</Text>
        
        <TouchableOpacity 
          style={[
            styles.timeOption, 
            deliveryTime === 'asap' && styles.selectedTime
          ]}
          onPress={() => setDeliveryTime('asap')}
        >
          <Text style={[
            styles.timeOptionText,
            deliveryTime === 'asap' && styles.selectedTimeText
          ]}>
            As soon as possible
          </Text>
          {deliveryTime === 'asap' && (
            <Ionicons name="checkmark-circle" size={24} color="#5C3BFE" />
          )}
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.timeOption, 
            deliveryTime === '12:00 PM - 2:00 PM' && styles.selectedTime
          ]}
          onPress={() => setDeliveryTime('12:00 PM - 2:00 PM')}
        >
          <Text style={[
            styles.timeOptionText,
            deliveryTime === '12:00 PM - 2:00 PM' && styles.selectedTimeText
          ]}>
            12:00 PM - 2:00 PM
          </Text>
          {deliveryTime === '12:00 PM - 2:00 PM' && (
            <Ionicons name="checkmark-circle" size={24} color="#5C3BFE" />
          )}
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.timeOption, 
            deliveryTime === '4:00 PM - 6:00 PM' && styles.selectedTime
          ]}
          onPress={() => setDeliveryTime('4:00 PM - 6:00 PM')}
        >
          <Text style={[
            styles.timeOptionText,
            deliveryTime === '4:00 PM - 6:00 PM' && styles.selectedTimeText
          ]}>
            4:00 PM - 6:00 PM
          </Text>
          {deliveryTime === '4:00 PM - 6:00 PM' && (
            <Ionicons name="checkmark-circle" size={24} color="#5C3BFE" />
          )}
        </TouchableOpacity>
      </View>
      
      {/* Order Summary Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Order Summary</Text>
        
        <View style={styles.summaryRow}>
          <Text style={styles.summaryText}>Items Total</Text>
          <Text style={styles.summaryValue}>${(total - 2.50).toFixed(2)}</Text>
        </View>
        
        <View style={styles.summaryRow}>
          <Text style={styles.summaryText}>Delivery Fee</Text>
          <Text style={styles.summaryValue}>$2.50</Text>
        </View>
        
        <View style={styles.divider} />
        
        <View style={styles.summaryRow}>
          <Text style={styles.totalText}>Total</Text>
          <Text style={styles.totalValue}>${total.toFixed(2)}</Text>
        </View>
      </View>
      
      {/* Place Order Button - replaced with custom Button component */}
      <View style={styles.buttonContainer}>
        <Button 
          title="Place Order" 
          onPress={placeOrder} 
          fullWidth 
          loading={isSubmitting} 
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 10,
    margin: 15,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  addressForm: {
    marginBottom: 10,
  },
  inputRow: {
    marginBottom: 15,
  },
  inputLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#eee',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  paymentOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#eee',
  },
  selectedPayment: {
    borderColor: '#5C3BFE',
    backgroundColor: '#F0EEFF',
  },
  paymentOptionText: {
    fontSize: 16,
    marginLeft: 10,
    flex: 1,
  },
  selectedPaymentText: {
    color: '#5C3BFE',
    fontWeight: '500',
  },
  timeOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#eee',
  },
  selectedTime: {
    borderColor: '#5C3BFE',
    backgroundColor: '#F0EEFF',
  },
  timeOptionText: {
    fontSize: 16,
  },
  selectedTimeText: {
    color: '#5C3BFE',
    fontWeight: '500',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  summaryText: {
    fontSize: 16,
    color: '#666',
  },
  summaryValue: {
    fontSize: 16,
    fontWeight: '500',
  },
  divider: {
    height: 1,
    backgroundColor: '#eee',
    marginVertical: 10,
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#5C3BFE',
  },
  buttonContainer: {
    padding: 15,
    marginBottom: 30,
  },
});