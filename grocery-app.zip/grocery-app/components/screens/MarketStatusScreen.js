import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';

export default function MarketStatusScreen({ route, navigation }) {
  const { isOpen } = route.params;
  const [showWelcome, setShowWelcome] = useState(true);
  
  useEffect(() => {
    if (isOpen) {
      // If market is open, auto-navigate to home after showing status briefly
      const timer = setTimeout(() => {
        navigation.replace('Home');
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [isOpen, navigation]);

  // Effect to hide welcome message
  useEffect(() => {
    const welcomeTimer = setTimeout(() => {
      setShowWelcome(false);
    }, 1000); // Hide welcome after 1 second
    
    return () => clearTimeout(welcomeTimer);
  }, []);

  return (
    <View style={styles.container}>
      <Image 
        source={require('../../assets/market-logo.png')} 
        style={styles.logo}
        resizeMode="contain"
      />
      
      {isOpen ? (
        <View style={styles.statusContainer}>
          <View style={[styles.statusIndicator, styles.open]} />
          <Text style={styles.statusText}>We're Open!</Text>
          {showWelcome && <Text style={styles.subtitle}>Welcome to our market</Text>}
        </View>
      ) : (
        <View style={styles.statusContainer}>
          <View style={[styles.statusIndicator, styles.closed]} />
          <Text style={styles.statusText}>We're Closed</Text>
          <Text style={styles.subtitle}>Opening Hours: 8:00 AM - 9:00 PM</Text> 
          
          <TouchableOpacity 
            style={styles.button}
            onPress={() => navigation.replace('Home')}
          >
            <Text style={styles.buttonText}>Browse Products</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFFFFF',
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 30,
  },
  statusContainer: {
    alignItems: 'center',
  },
  statusIndicator: {
    width: 20,
    height: 20,
    borderRadius: 10,
    marginBottom: 10,
  },
  open: {
    backgroundColor: '#4CAF50',
  },
  closed: {
    backgroundColor: '#F44336',
  },
  statusText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
    color: '#666666',
  },
  button: {
    backgroundColor: '#5C3BFE',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 30,
    marginTop: 20,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});