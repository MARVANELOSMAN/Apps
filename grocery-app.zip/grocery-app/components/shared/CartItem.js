import React, { memo } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * Component for showing items in the cart with quantity controls
 * @param {Object} props
 * @param {string} props.id - Product ID
 * @param {string} props.name - Product name
 * @param {string} props.image - Product image URI
 * @param {number} props.price - Product price
 * @param {number} props.quantity - Quantity of product in cart
 * @param {string} props.unit - Unit of measurement (kg, g, etc.)
 * @param {function} props.onIncrement - Function to increase quantity
 * @param {function} props.onDecrement - Function to decrease quantity
 * @param {function} props.onRemove - Function to remove item from cart
 * @param {Object} props.style - Additional styles for the container
 */
const CartItem = memo(({
  id,
  name,
  image,
  price,
  quantity,
  unit = '',
  onIncrement,
  onDecrement,
  onRemove,
  style
}) => {
  const totalPrice = price * quantity;
  
  const handleIncrement = () => {
    if (onIncrement) onIncrement(id);
  };
  
  const handleDecrement = () => {
    if (quantity <= 1) {
      if (onRemove) onRemove(id);
    } else {
      if (onDecrement) onDecrement(id);
    }
  };
  
  const handleRemove = () => {
    if (onRemove) onRemove(id);
  };

  return (
    <View style={[styles.container, style]}>
      <Image 
        source={typeof image === 'string' ? { uri: image } : image}
        style={styles.image}
        resizeMode="cover"
        defaultSource={require('../../assets/placeholder-product.png')}
      />
      
      <View style={styles.contentContainer}>
        <View style={styles.infoContainer}>
          <Text style={styles.name} numberOfLines={1}>
            {name}
          </Text>
          {unit && (
            <Text style={styles.unit}>
              {unit}
            </Text>
          )}
          <Text style={styles.price}>
            ${price.toFixed(2)}
          </Text>
        </View>
        
        <View style={styles.actionsContainer}>
          <TouchableOpacity 
            onPress={handleRemove}
            style={styles.removeButton}
            accessibilityLabel="Remove item"
          >
            <Ionicons name="trash-outline" size={18} color="#FF3B30" />
          </TouchableOpacity>
          
          <View style={styles.quantityContainer}>
            <TouchableOpacity 
              onPress={handleDecrement}
              style={styles.quantityButton}
              accessibilityLabel="Decrease quantity"
            >
              <Ionicons name="remove" size={18} color="#333" />
            </TouchableOpacity>
            
            <Text style={styles.quantity}>
              {quantity}
            </Text>
            
            <TouchableOpacity 
              onPress={handleIncrement}
              style={styles.quantityButton}
              accessibilityLabel="Increase quantity"
            >
              <Ionicons name="add" size={18} color="#333" />
            </TouchableOpacity>
          </View>
          
          <Text style={styles.totalPrice}>
            ${totalPrice.toFixed(2)}
          </Text>
        </View>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    padding: 12,
    backgroundColor: '#FFF',
    borderRadius: 12,
    marginVertical: 8,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 12,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'space-between',
  },
  infoContainer: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 2,
  },
  unit: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  price: {
    fontSize: 14,
    color: '#666',
  },
  actionsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  removeButton: {
    padding: 4,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
  },
  quantityButton: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantity: {
    width: 24,
    textAlign: 'center',
    fontSize: 14,
    fontWeight: '500',
  },
  totalPrice: {
    fontSize: 16,
    fontWeight: '600',
    color: '#5C3BFE',
  },
});

export default CartItem;