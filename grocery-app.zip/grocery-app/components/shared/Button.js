import React from 'react';
import { 
  TouchableOpacity, 
  Text, 
  StyleSheet, 
  ActivityIndicator 
} from 'react-native';

/**
 * A reusable button component with various styles and states
 * @param {Object} props
 * @param {string} props.title - Button text
 * @param {function} props.onPress - Function to call when button is pressed
 * @param {string} props.type - Button type (primary, secondary, outline, text)
 * @param {string} props.size - Button size (small, medium, large)
 * @param {boolean} props.fullWidth - Whether button should take full width
 * @param {boolean} props.loading - Whether to show loading indicator
 * @param {boolean} props.disabled - Whether button is disabled
 * @param {Object} props.style - Additional styles for the button
 * @param {Object} props.textStyle - Additional styles for the button text
 */
const Button = ({
  title,
  onPress,
  type = 'primary',
  size = 'medium',
  fullWidth = false,
  loading = false,
  disabled = false,
  style,
  textStyle,
  ...restProps
}) => {
  const getBackgroundColor = () => {
    if (disabled) return '#CCCCCC';
    
    switch (type) {
      case 'primary':
        return '#5C3BFE';
      case 'secondary':
        return '#FF9500';
      case 'outline':
      case 'text':
        return 'transparent';
      default:
        return '#5C3BFE';
    }
  };
  
  const getBorderColor = () => {
    if (disabled) return '#CCCCCC';
    
    switch (type) {
      case 'outline':
        return '#5C3BFE';
      default:
        return 'transparent';
    }
  };
  
  const getTextColor = () => {
    if (disabled) return '#FFFFFF';
    
    switch (type) {
      case 'primary':
      case 'secondary':
        return '#FFFFFF';
      case 'outline':
        return '#5C3BFE';
      case 'text':
        return '#5C3BFE';
      default:
        return '#FFFFFF';
    }
  };
  
  const getHeight = () => {
    switch (size) {
      case 'small':
        return 36;
      case 'medium':
        return 48;
      case 'large':
        return 56;
      default:
        return 48;
    }
  };
  
  const containerStyles = [
    styles.button,
    { backgroundColor: getBackgroundColor() },
    { borderColor: getBorderColor() },
    { height: getHeight() },
    type === 'outline' && styles.outlineButton,
    fullWidth && styles.fullWidth,
    style
  ];
  
  const textStyles = [
    styles.text,
    { color: getTextColor() },
    size === 'small' && styles.smallText,
    size === 'large' && styles.largeText,
    textStyle
  ];
  
  const accessibilityState = {
    disabled: disabled || loading
  };

  return (
    <TouchableOpacity
      onPress={onPress}
      style={containerStyles}
      disabled={disabled || loading}
      accessibilityRole="button"
      accessibilityState={accessibilityState}
      activeOpacity={0.7}
      {...restProps}
    >
      {loading ? (
        <ActivityIndicator 
          size="small" 
          color={getTextColor()} 
        />
      ) : (
        <Text style={textStyles}>
          {title}
        </Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  outlineButton: {
    borderWidth: 1,
  },
  fullWidth: {
    width: '100%',
  },
  text: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  smallText: {
    fontSize: 14,
  },
  largeText: {
    fontSize: 18,
  },
});

export default Button;