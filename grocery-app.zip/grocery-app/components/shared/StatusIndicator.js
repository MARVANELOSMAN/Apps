import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

/**
 * A component to show market/order status with various status types
 * @param {Object} props
 * @param {string} props.status - The current status (success, error, warning, info, pending, etc.)
 * @param {string} props.text - The text to display
 * @param {string} props.size - Size of the indicator (small, medium, large)
 * @param {boolean} props.showDot - Whether to show status dot
 * @param {Object} props.style - Additional styles for the container
 * @param {Object} props.textStyle - Additional styles for the text
 * @param {Object} props.dotStyle - Additional styles for the dot
 */
const StatusIndicator = ({
  status = 'pending',
  text,
  size = 'medium',
  showDot = true,
  style,
  textStyle,
  dotStyle
}) => {
  // Status color mapping
  const statusColors = {
    success: '#34C759',    // Green
    error: '#FF3B30',      // Red
    warning: '#FF9500',    // Orange
    info: '#007AFF',       // Blue
    pending: '#FF9500',    // Orange
    processing: '#5C3BFE', // Purple
    delivered: '#34C759',  // Green
    cancelled: '#FF3B30',  // Red
    open: '#34C759',       // Green
    closed: '#FF3B30',     // Red
  };
  
  // Default to gray if status not found
  const dotColor = statusColors[status.toLowerCase()] || '#8E8E93';
  
  // Determine dot size based on component size
  const getDotSize = () => {
    switch (size) {
      case 'small':
        return 8;
      case 'medium':
        return 10;
      case 'large':
        return 12;
      default:
        return 10;
    }
  };
  
  // Determine font size based on component size
  const getFontSize = () => {
    switch (size) {
      case 'small':
        return 12;
      case 'medium':
        return 14;
      case 'large':
        return 16;
      default:
        return 14;
    }
  };
  
  return (
    <View style={[styles.container, style]}>
      {showDot && (
        <View
          style={[
            styles.dot,
            {
              backgroundColor: dotColor,
              width: getDotSize(),
              height: getDotSize(),
            },
            dotStyle
          ]}
        />
      )}
      {text && (
        <Text
          style={[
            styles.text,
            { fontSize: getFontSize() },
            textStyle
          ]}
        >
          {text}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  dot: {
    borderRadius: 50,
    marginRight: 6,
  },
  text: {
    color: '#333333',
    fontWeight: '500',
  },
});

export default StatusIndicator;