import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

/**
 * Reusable header component with title, back button, cart icon, and profile icon
 * @param {Object} props
 * @param {string} props.title - The header title
 * @param {boolean} props.showBack - Whether to show the back button (default: true)
 * @param {boolean} props.showCart - Whether to show the cart icon (default: true)
 * @param {boolean} props.showProfile - Whether to show the profile icon (default: false)
 * @param {function} props.onCartPress - Custom function for cart press
 * @param {function} props.onBackPress - Custom function for back press
 * @param {function} props.onProfilePress - Custom function for profile press
 * @param {Object} props.style - Additional styles for the header container
 */
const Header = ({ 
  title, 
  showBack = true, 
  showCart = true,
  showProfile = false,
  onCartPress, 
  onBackPress,
  onProfilePress,
  style
}) => {
  const navigation = useNavigation();

  const handleBackPress = () => {
    if (onBackPress) {
      onBackPress();
    } else {
      navigation.goBack();
    }
  };

  const handleCartPress = () => {
    if (onCartPress) {
      onCartPress();
    } else {
      navigation.navigate('Cart');
    }
  };

  const handleProfilePress = () => {
    if (onProfilePress) {
      onProfilePress();
    } else {
      navigation.navigate('Profile');
    }
  };

  return (
    <View style={[styles.container, style]}>
      <View style={styles.leftContainer}>
        {showBack && (
          <TouchableOpacity 
            onPress={handleBackPress} 
            style={styles.backButton}
            accessibilityLabel="Go back"
          >
            <Ionicons name="chevron-back" size={24} color="#333" />
          </TouchableOpacity>
        )}
      </View>
      
      <Text style={styles.title} numberOfLines={1} ellipsizeMode="tail">
        {title}
      </Text>
      
      <View style={styles.rightContainer}>
        {showCart && (
          <TouchableOpacity 
            onPress={handleCartPress} 
            style={styles.iconButton}
            accessibilityLabel="View cart"
          >
            <Ionicons name="cart-outline" size={24} color="#333" />
          </TouchableOpacity>
        )}
        {showProfile && (
          <TouchableOpacity 
            onPress={handleProfilePress} 
            style={styles.iconButton}
            accessibilityLabel="View profile"
          >
            <Ionicons name="person-circle" size={24} color="#333" />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 56,
    backgroundColor: '#FFF',
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  leftContainer: {
    width: 40,
    alignItems: 'flex-start',
  },
rightContainer: {
  flexDirection: 'row',
  justifyContent: 'flex-end',
},
  title: {
    flex: 1,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '600',
    color: '#333333',
  },
  backButton: {
    padding: 4,
  },
  iconButton: {
    padding: 4,
    marginLeft: 8,
  },
});

export default Header;