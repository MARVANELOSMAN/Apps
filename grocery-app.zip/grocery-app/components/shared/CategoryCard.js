import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';

/**
 * Reusable card component for displaying grocery categories
 * @param {Object} props
 * @param {string} props.id - Category ID
 * @param {string} props.name - Category name
 * @param {string} props.image - Image URI for the category
 * @param {number} props.itemCount - Number of items in the category
 * @param {function} props.onPress - Custom onPress handler
 * @param {Object} props.style - Custom styles for the card container
 */
const CategoryCard = ({
  id,
  name,
  image,
  itemCount,
  onPress,
  style
}) => {
  const navigation = useNavigation();

  const handlePress = () => {
    if (onPress) {
      onPress({ id, name });
    } else {
      navigation.navigate('Category', { 
        categoryId: id, 
        categoryName: name
      });
    }
  };

  return (
    <TouchableOpacity 
      style={[styles.container, style]} 
      onPress={handlePress}
      activeOpacity={0.7}
      accessibilityLabel={`${name} category with ${itemCount} items`}
    >
      <View style={styles.card}>
        <Image
          source={typeof image === 'string' ? { uri: image } : image}
          style={styles.image}
          resizeMode="cover"
          defaultSource={require('../../assets/placeholder-category.jpg')}
        />
        <View style={styles.overlay}>
          <Text style={styles.name} numberOfLines={1}>
            {name}
          </Text>
          {itemCount !== undefined && (
            <Text style={styles.count}>
              {itemCount} {itemCount === 1 ? 'item' : 'items'}
            </Text>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    margin: 8,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    backgroundColor: '#FFF',
    overflow: 'hidden',
  },
  card: {
    width: 160,
    height: 120,
    justifyContent: 'flex-end',
  },
  image: {
    ...StyleSheet.absoluteFillObject,
    width: '100%',
    height: '100%',
    borderRadius: 12,
  },
  overlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    padding: 12,
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
  },
  name: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 16,
  },
  count: {
    color: '#EEEEEE',
    fontSize: 12,
    marginTop: 2,
  },
});

export default CategoryCard;